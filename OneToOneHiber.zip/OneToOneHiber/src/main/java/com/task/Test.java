package com.task;

//import java.util.HashMap;
//import java.util.Map;


public class Test
{ 
	
	public static void main(String[] args)
	{ 
		int[] x = {1, 2, 3, 4};
		int[] y = x;
		x = new int[3]; 
		for(int i = 0; i < x.length; i++) 
			System.out.print(y[i] + " "); 
		}
	}




